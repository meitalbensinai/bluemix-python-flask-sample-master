Hi there,
This data was collected during our research.
The research focus is to measure similarity between code fragments using natural language meta data that is associated with the code.
Further details can be found at my MSC dissertation: http://cs.technion.ac.il/users/wwwb/cgi-bin/tr-info.cgi/2015/MSC/MSC-2015-16
http://like2drops.com is the web application that we used for building this corpus of related code fragments.

This zip contains 3 different collections:
	--pairs_with_user_scores.json
		this collection is in the following structure:
		-pair_id
		-code1: first code
		-code2: second code
		-grades: list of all the grades that the users gave to this pair.
				 map -
				 "Very similar": 5, 
				 "Pretty similar": 4, 
				 "Related, but not similar": 3, 
				 "Pretty different": 2,
				 "Totally different": 1
		-lang1: the language of the first code
		-lang2: the language of the second code
	--pairs_with_our_score.json
		this collection is in the following structure:
		-pair_id
		-score: our similarity score
		-similarity: our decision - similar or not
	--pairs_with_metadata.json
		this collection is in the following structure:
		-pair_id
		-code1: first code
		-code2: second code
		-lang1: the language of the first code
		-lang2: the language of the second code
		-title1: the most informative text regarding the first code
		-title2: the most informative text regarding the second code
		-text1: some other text that is associated with the first code
		-text2: some other text that is associated with the second code
		titles & texts were taken out from Stackoverflow questions and have been processed.
		
Enjoy and let us know if you make any use of our data.
Best,
Meital Zilberstein & Eran Yahav
mbs/yahave@cs.technion.ac.il

	